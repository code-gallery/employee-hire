export { default } from './InstallAppBanner'
