import appIcon from './app-icon.png'

export default {
  appIcon
}
