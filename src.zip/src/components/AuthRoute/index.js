export { default } from './AuthRoute.js'
