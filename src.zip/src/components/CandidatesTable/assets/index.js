import mobile from './mobile.png'
import name from './name.png'
import latest_organization from './latest_organization.png'
import latest_role from './latest_role.png'
import latest_request from './latest_request.png'
import officer_name from './officer_name.png'
import status from './status.png'
import last_nudge from './last_nudge.png'
import last_activity from './last_activity.png'




export default {
    last_activity,
    last_nudge,
    latest_organization,
    latest_request,
    latest_role,
    mobile,
    name,
    officer_name,
    status
}
