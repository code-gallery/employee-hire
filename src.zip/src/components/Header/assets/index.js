import logo from './logo.svg'

export default {
  logo
}
