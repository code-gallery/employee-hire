export { default } from './ScrollToTop'
