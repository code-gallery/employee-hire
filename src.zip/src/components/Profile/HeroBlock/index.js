export { default } from './HeroBlock'
