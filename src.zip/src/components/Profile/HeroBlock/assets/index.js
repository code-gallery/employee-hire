import placeholder from './banner-placeholder.png'

export default {
  placeholder
}
