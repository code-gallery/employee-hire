import iconDanger from './icon-danger.png'
import iconVerified from './icon-verified.svg'
import iconLocation from './location_ico.svg'

export default {
  iconDanger,
  iconVerified,
  iconLocation
}
