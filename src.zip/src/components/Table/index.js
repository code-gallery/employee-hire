import './style.css'

export { default as Table } from './Table'
export { default as TableHeading } from './TableHeading'
export { default as TableData } from './TableData'
