import linkedinLogo from './linkedin_logo.svg'
import facebookLogo from './facebook_logo.svg'
import twitterLogo from './twitter_logo.svg'

export default {
  linkedinLogo,
  facebookLogo,
  twitterLogo
}
