export { default } from './Footer'
