import grayIcon from './gray-ico.svg'
import greenIcon from './green-ico.svg'
import redIcon from './red-ico.svg'
import yellowIcon from './yellow-ico.svg'

export default {
  grayIcon,
  greenIcon,
  redIcon,
  yellowIcon
}
