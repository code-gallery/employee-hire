export { default } from './ContentCard.js'
