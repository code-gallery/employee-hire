export { default } from './LinkedButton'
