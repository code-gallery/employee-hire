import placeholder from './appii-placeholder.png'

export default {
  placeholder
}
