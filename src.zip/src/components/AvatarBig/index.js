export { default } from './AvatarBig.js'
