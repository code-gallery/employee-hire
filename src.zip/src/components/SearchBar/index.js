export { default } from './SearchBar.js'
