export { default } from './LinkedAvatar'
