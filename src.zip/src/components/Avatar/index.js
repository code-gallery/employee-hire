export { default } from './Avatar.js'
