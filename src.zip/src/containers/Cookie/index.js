export { default } from './Cookie.js'
