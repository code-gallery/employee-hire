export { default } from './ForgotPassword.js'
