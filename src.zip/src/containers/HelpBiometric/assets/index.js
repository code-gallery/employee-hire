import mobileBiometric from './mobile-biometric.png'
import mobileScreens from './mobile-screens.png'
import downloadApple from './download-apple.svg'
import downloadGoogle from './download-google.png'

export default {
  downloadApple,
  downloadGoogle,
  mobileBiometric,
  mobileScreens
}
