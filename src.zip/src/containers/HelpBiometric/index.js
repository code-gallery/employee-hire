export { default } from './HelpBiometric.js'
