export { default } from './LinkedInSearchResults'
