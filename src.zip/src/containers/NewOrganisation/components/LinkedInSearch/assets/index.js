import linkedIn from './linkedin-signin.png'

export default {
  linkedIn
}
