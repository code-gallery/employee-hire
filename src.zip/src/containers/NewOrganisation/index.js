export { default, mapState, mapDispatch } from './connect'
