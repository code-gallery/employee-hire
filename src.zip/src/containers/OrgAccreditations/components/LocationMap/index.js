export { default } from './LocationMap'
