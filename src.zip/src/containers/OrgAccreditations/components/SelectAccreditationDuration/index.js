export { default } from './SelectAccreditationDuration'
