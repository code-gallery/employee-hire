export { default } from './Candidate'
