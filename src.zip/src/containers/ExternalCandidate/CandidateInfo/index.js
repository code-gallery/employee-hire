export { default } from './CandidateInfo'
